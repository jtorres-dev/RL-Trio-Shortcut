#
# This script is designed to simplify the task of opening up DS4Windows, BakkesMod, and Rocket League seperately.
# It will search for the location of DS4, BakkesMod, and Rocket League, and will create an icon with the Rocket League
# logo (which replaces your actual Rocket League icon) which allows all three programs to be opened up at the same
# time with one link. The first time running this script will be slow since it will have to search for the given programs
# but afterwards the paths for each program is saved to a Paths.txt file where your Binaries for RocketLeague is located
# which will make the execution faster.
#
# DISCLAIMER: IF YOU DO NOT HAVE ALL THREE PROGRAMS DOWNLOADED, DO NOT RUN THIS SCRIPT. IT WILL CAUSE ERRORS AND 
# WILL NOT WORK PROPERLY.
#
# Author: Johnobomb
# Date: November 6, 2020
# Version: 1.0
#

$script_location = (pwd).toString()

cd \

$rl_dir = ""
$rl_path = ""

# -join ends up converting the disk output to a string
$ls_disks = (wmic logicaldisk get name | Select-String -Pattern '.:') -join '';
$disks = $ls_disks.Split(" ")

foreach ($disk in $disks) {

	# when splitting, there are some blank entries for some indices in the disks array
	if ($disk -match '.:') {

		$paths_exists = Test-Path "$disk\*\Steam\steamapps\common\rocketleague\Binaries\Paths.txt"
		if ($paths_exists) {
			$paths = Get-Content ((Resolve-Path "$disk\*\Steam\steamapps\common\rocketleague\Binaries" | Select -ExpandProperty Path) + "\Paths.txt")
			$paths = $paths.Split([Environment]::NewLine)
			Start-Process -FilePath $paths[0]
			Start-Process -FilePath $paths[1]
			Start-Process -FilePath $paths[2]
			exit
		}
		
		$rl_exists = Test-Path "$disk\*\Steam\steamapps\common\rocketleague\Binaries\RocketLeague.exe"

		if ($rl_exists) {
			Write-Host "Searching for RocketLeague.exe ..."
			$rl_dir = (Resolve-Path "$disk\*\Steam\steamapps\common\rocketleague\Binaries" | Select -ExpandProperty Path)
			$rl_path = $rl_dir + "\RocketLeague.exe"
			$rl_dir += "\Paths.txt"
			break
		}
	}
}

Write-Host "Searching for DS4Windows.exe ..."
$DS4_path = (Get-ChildItem -recurse "DS4Windows.exe" -File -ErrorAction SilentlyContinue | Select-Object -First 1).toString()

Write-Host "Searching for BakkesMod.exe ..."
$bakkes_path = (Get-ChildItem -recurse "BakkesMod.exe" -File -ErrorAction SilentlyContinue | Select-Object -First 1).toString()

# saves paths of bakkesMod, DS4, and RL to a Paths.txt located in the Binaries folder for Rocket League.
"$bakkes_path`n$DS4_path`n$rl_path" | Out-File -FilePath $rl_dir
Write-Host "Paths found!"

# creates a shortcut on the desktop
$script_obj = New-Object -ComObject WScript.Shell
$shortcut = $script_obj.CreateShortcut("$Home\Desktop\Rocket League.lnk")
$shortcut.IconLocation = $script_location + "\RL.ico"
$script_location += "\RL script.ps1"
$shortcut.TargetPath = $script_location
$shortcut.Save()